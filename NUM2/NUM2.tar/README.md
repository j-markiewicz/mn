# NUM2

## Wymagania

- [`wolframscript`](https://www.wolfram.com/wolframscript/)

## Używanie

- Program wykonuje się używając komendy `wolframscript -file ./NUM2.wls`

Program rozwiąże równania z zadania i wypisze wartości użyte w PDFie.
