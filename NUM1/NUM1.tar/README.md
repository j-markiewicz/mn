# NUM1

## Wymagania

- [Python 3](https://www.python.org/)
- [matplotlib](https://matplotlib.org/)
- [NumPy](https://numpy.org/)

## Używanie

- Program wykonuje się używając komendy `py NUM1.py` (Windows) lub `python3 NUM1.py` (wszystkie inne) - powinien się pokazać wykres podobny do drugiego w PDFie
- Można zmienić liczbe różnych wartości `h` przy pomocy `[komenda] --samples=[liczba]` (trzeci wykres używa `--samples=1000`)
- Można zmienić styl wykresu na komiksowy przy pomocy `[komenda] --comic` (podobnie do pierwszego wykresu)

Przy wykonaniu program również wypisuje wartości najmniejszych błędów i odpowiadających wartości `h` dla wszystkich algorytmów i typów danych.
