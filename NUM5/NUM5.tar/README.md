# NUM5

## Wymagania

- [Rust i Cargo](https://rustup.rs/)

## Użycie

- Program wykonuje się używając komendy `cargo run`. Program zapisze wykresy błędów dla wybranej (przez `--starting-points [liczba]`) liczby punktów startowych oraz wypisze przykładowe rozwiązania dla N = 10.
