# NUM4

## Wymagania

- [Rust i Cargo](https://rustup.rs/)

## Użycie

- Program wykonuje się używając komendy `cargo run`. Program wypisze wartości zmiennych dla N = 10 i wynik równania dla N = 80.
- Pomiary czasu wykonania wykonuje się używając komendy `cargo bench`. Wyniki pomiaru będą umieszczone w katalogu `target/criterion`.
