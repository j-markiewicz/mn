# NUM9

## Wymagania

- [Python 3](https://www.python.org/)
- [matplotlib](https://matplotlib.org/)
- [NumPy](https://numpy.org/)

## Używanie

- Program wykonuje się używając komendy `py NUM9.py` (Windows) lub `python3 NUM9.py` (wszystkie inne)
- Przy wykonaniu `[komenda] f` obliczony zostanie pierwiastek funkcji f
- Przy wykonaniu `[komenda] g` obliczony zostanie pierwiestek funkcji g
