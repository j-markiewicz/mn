# NUM3

## Wymagania

- [Rust i Cargo](https://rustup.rs/)

## Użycie

- Program wykonuje się używając komendy `cargo run`. Program wypisze przykładowy rozkład LU oraz wynik równania.
- Pomiary czasu wykonania wykonuje się używając komendy `cargo bench`. Wyniki pomiaru będą umieszczone w katalogu `target/criterion`.
