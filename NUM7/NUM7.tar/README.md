# NUM7

## Wymagania

- [Python 3](https://www.python.org/)
- [matplotlib](https://matplotlib.org/)
- [NumPy](https://numpy.org/)

## Używanie

- Program wykonuje się używając komendy `py NUM6.py` (Windows) lub `python3 NUM6.py` (wszystkie inne)
- Przy wykonaniu `[komenda]` wyświetli się wykres dla obu podpunktów
- Przy wykonaniu `[komenda] a` rozwiązany będzie podpunkt *a* i wyświetli się do niego wykres oraz wypiszą się dane
- Przy wykonaniu `[komenda] b` rozwiązany będzie podpunkt *b* i wyświetli się do niego wykres oraz wypiszą się dane
